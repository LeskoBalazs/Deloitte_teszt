﻿using System;

namespace Deloitte_programozas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1. FELADAT:");
            Object[] myArray = new Object[7];
            string input;
            string option;
            for (int i = 0; i <= myArray.Length-1; i++)
            {
 
                    Console.WriteLine("Milyen típusú objektumot szeretnél? Szám(n), vagy szöveg(s)?");
                    option = Console.ReadLine();
                    if (option == "n")
                    {
                        do
                        {
                            Console.WriteLine("Adj meg egy számot!");
                            input = Console.ReadLine();
                            if (Int32.Parse(input) >= 10 && Int32.Parse(input) <= 9999)
                                myArray[i] = Int32.Parse(input); //ha teljesül a feltétel, a tömbhöz adjuk számmá castolva
                        else
                            {
                                Console.WriteLine("Kérlek 10 és 9999 közötti számot adj meg!");
                            }
                        } while (Int32.Parse(input) < 10 || Int32.Parse(input) > 9999); // amíg jó inputot nem ad a felhasználó

                    }
                    else if (option == "s")
                    {
                        do
                        {
                            Console.WriteLine("Adj meg egy szót!");
                            input = Console.ReadLine();
                            if (input.Length >= 5 && input.Length <= 45) //ha teljesül a feltétel, a tömbhöz adjuk
                                myArray[i] = input;
                            else
                            {
                                Console.WriteLine("Kérlek 5 és 45 karakter közötti hosszúságú szót adj meg!");
                            }
                        } while (input.Length < 5 || input.Length > 45); // amíg jó inputot nem ad a felhasználó

                }
                    else //kiürítjük a tömböt, hogy ne kapjunk hibát és bezárjuk a programot
                    {
                        Console.WriteLine("Nem jó karaktert adtál meg, indítsd újra a programot!");
                        Array.Clear(myArray, 0, myArray.Length);
                        System.Environment.Exit(1);
                    }
               


            }
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.WriteLine("2. FELADAT:");
            string example = "Making an impact that matters – Deloitte";
            bool isPrime = false; 
            string sub;
            int a = 0;
            int m = myArray.Length;
            for (int i = 0; i <= myArray.Length - 1; i++)
            {
                if(myArray[i].GetType() == typeof(int))
                {
                    for (int j=1; j <= (int)myArray[i]; j++)
                    {
                        if ((int)myArray[i] % j == 0) //prímvizsgálat
                            a++;
                    }
                    if (a == 2) //2 érték (önmaga és 1) esetén lesz igaz
                        isPrime = true;

                    if ((int)myArray[i] % 2 == 0)
                    { 
                            Console.WriteLine((int)myArray[i] + " - " + (int)myArray[i] / 2);
                    }
                    else
                    {
                        if (isPrime) //csak a páratlan eset kell, mert 10 vagy annál nagyobb számaink vannak, ergó a 2, mint egyetlen páros prímszám nem játszik
                            Console.WriteLine((int)myArray[i] + " - " + (int)myArray[i] * 2 + " !prímszám");
                        else
                            Console.WriteLine((int)myArray[i] + " - " + (int)myArray[i] * 2);
                    }
                }
                else if(myArray[i].GetType() == typeof(string))
                {
                    sub = example.Substring(0, myArray[i].ToString().Length); //a 0-ás indextől az adott szó hosszáig levágjuk a megadott példaszöveg karaktereit és a szó után fűzzük
                    Console.WriteLine(myArray[i]+ " - " + sub);
                }
            }
            Console.ReadKey();
        }
    }
}
